﻿namespace ProiectIP
{
    partial class Inregistrare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.Username = new System.Windows.Forms.Label();
            this.Parola = new System.Windows.Forms.Label();
            this.Nume = new System.Windows.Forms.Label();
            this.Prenume = new System.Windows.Forms.Label();
            this.CNP = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Adresa = new System.Windows.Forms.Label();
            this.Oras = new System.Windows.Forms.Label();
            this.Telefon = new System.Windows.Forms.Label();
            this.textBoxParola = new System.Windows.Forms.TextBox();
            this.textBoxNume = new System.Windows.Forms.TextBox();
            this.textBoxPrenume = new System.Windows.Forms.TextBox();
            this.textBoxCNP = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxAdresa = new System.Windows.Forms.TextBox();
            this.textBoxOras = new System.Windows.Forms.TextBox();
            this.textBoxTelefon = new System.Windows.Forms.TextBox();
            this.backLogIn = new System.Windows.Forms.Button();
            this.buttonInregistrare = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(155, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(463, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bun venit pe pagina de înregistrare!";
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUsername.Location = new System.Drawing.Point(294, 83);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(176, 27);
            this.textBoxUsername.TabIndex = 1;
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username.Location = new System.Drawing.Point(192, 90);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(86, 20);
            this.Username.TabIndex = 2;
            this.Username.Text = "Username";
            this.Username.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Parola
            // 
            this.Parola.AutoSize = true;
            this.Parola.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Parola.Location = new System.Drawing.Point(221, 132);
            this.Parola.Name = "Parola";
            this.Parola.Size = new System.Drawing.Size(57, 20);
            this.Parola.TabIndex = 3;
            this.Parola.Text = "Parolă";
            this.Parola.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Nume
            // 
            this.Nume.AutoSize = true;
            this.Nume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nume.Location = new System.Drawing.Point(225, 178);
            this.Nume.Name = "Nume";
            this.Nume.Size = new System.Drawing.Size(53, 20);
            this.Nume.TabIndex = 4;
            this.Nume.Text = "Nume";
            this.Nume.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Prenume
            // 
            this.Prenume.AutoSize = true;
            this.Prenume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Prenume.Location = new System.Drawing.Point(202, 222);
            this.Prenume.Name = "Prenume";
            this.Prenume.Size = new System.Drawing.Size(76, 20);
            this.Prenume.TabIndex = 5;
            this.Prenume.Text = "Prenume";
            this.Prenume.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // CNP
            // 
            this.CNP.AutoSize = true;
            this.CNP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CNP.Location = new System.Drawing.Point(234, 268);
            this.CNP.Name = "CNP";
            this.CNP.Size = new System.Drawing.Size(44, 20);
            this.CNP.TabIndex = 6;
            this.CNP.Text = "CNP";
            this.CNP.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(227, 308);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(51, 20);
            this.Email.TabIndex = 7;
            this.Email.Text = "Email";
            this.Email.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Adresa
            // 
            this.Adresa.AutoSize = true;
            this.Adresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adresa.Location = new System.Drawing.Point(216, 356);
            this.Adresa.Name = "Adresa";
            this.Adresa.Size = new System.Drawing.Size(62, 20);
            this.Adresa.TabIndex = 8;
            this.Adresa.Text = "Adresă";
            this.Adresa.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Oras
            // 
            this.Oras.AutoSize = true;
            this.Oras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Oras.Location = new System.Drawing.Point(232, 401);
            this.Oras.Name = "Oras";
            this.Oras.Size = new System.Drawing.Size(46, 20);
            this.Oras.TabIndex = 9;
            this.Oras.Text = "Oraș";
            this.Oras.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // Telefon
            // 
            this.Telefon.AutoSize = true;
            this.Telefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Telefon.Location = new System.Drawing.Point(214, 452);
            this.Telefon.Name = "Telefon";
            this.Telefon.Size = new System.Drawing.Size(64, 20);
            this.Telefon.TabIndex = 10;
            this.Telefon.Text = "Telefon";
            this.Telefon.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // textBoxParola
            // 
            this.textBoxParola.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxParola.Location = new System.Drawing.Point(294, 125);
            this.textBoxParola.Name = "textBoxParola";
            this.textBoxParola.Size = new System.Drawing.Size(176, 27);
            this.textBoxParola.TabIndex = 11;
            // 
            // textBoxNume
            // 
            this.textBoxNume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNume.Location = new System.Drawing.Point(294, 171);
            this.textBoxNume.Name = "textBoxNume";
            this.textBoxNume.Size = new System.Drawing.Size(176, 27);
            this.textBoxNume.TabIndex = 12;
            // 
            // textBoxPrenume
            // 
            this.textBoxPrenume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPrenume.Location = new System.Drawing.Point(294, 215);
            this.textBoxPrenume.Name = "textBoxPrenume";
            this.textBoxPrenume.Size = new System.Drawing.Size(176, 27);
            this.textBoxPrenume.TabIndex = 13;
            // 
            // textBoxCNP
            // 
            this.textBoxCNP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCNP.Location = new System.Drawing.Point(294, 261);
            this.textBoxCNP.Name = "textBoxCNP";
            this.textBoxCNP.Size = new System.Drawing.Size(176, 27);
            this.textBoxCNP.TabIndex = 14;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmail.Location = new System.Drawing.Point(294, 301);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(176, 27);
            this.textBoxEmail.TabIndex = 15;
            // 
            // textBoxAdresa
            // 
            this.textBoxAdresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAdresa.Location = new System.Drawing.Point(294, 349);
            this.textBoxAdresa.Name = "textBoxAdresa";
            this.textBoxAdresa.Size = new System.Drawing.Size(176, 27);
            this.textBoxAdresa.TabIndex = 16;
            // 
            // textBoxOras
            // 
            this.textBoxOras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOras.Location = new System.Drawing.Point(294, 394);
            this.textBoxOras.Name = "textBoxOras";
            this.textBoxOras.Size = new System.Drawing.Size(176, 27);
            this.textBoxOras.TabIndex = 17;
            // 
            // textBoxTelefon
            // 
            this.textBoxTelefon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTelefon.Location = new System.Drawing.Point(294, 445);
            this.textBoxTelefon.Name = "textBoxTelefon";
            this.textBoxTelefon.Size = new System.Drawing.Size(176, 27);
            this.textBoxTelefon.TabIndex = 18;
            // 
            // backLogIn
            // 
            this.backLogIn.Location = new System.Drawing.Point(583, 445);
            this.backLogIn.Name = "backLogIn";
            this.backLogIn.Size = new System.Drawing.Size(185, 62);
            this.backLogIn.TabIndex = 19;
            this.backLogIn.Text = "Înapoi la LogIn";
            this.backLogIn.UseVisualStyleBackColor = true;
            this.backLogIn.Click += new System.EventHandler(this.backLogIn_Click);
            // 
            // buttonInregistrare
            // 
            this.buttonInregistrare.Location = new System.Drawing.Point(583, 364);
            this.buttonInregistrare.Name = "buttonInregistrare";
            this.buttonInregistrare.Size = new System.Drawing.Size(185, 57);
            this.buttonInregistrare.TabIndex = 20;
            this.buttonInregistrare.Text = "Înregistrare";
            this.buttonInregistrare.UseVisualStyleBackColor = true;
            this.buttonInregistrare.Click += new System.EventHandler(this.buttonInregistrare_Click);
            // 
            // Inregistrare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 527);
            this.Controls.Add(this.buttonInregistrare);
            this.Controls.Add(this.backLogIn);
            this.Controls.Add(this.textBoxTelefon);
            this.Controls.Add(this.textBoxOras);
            this.Controls.Add(this.textBoxAdresa);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxCNP);
            this.Controls.Add(this.textBoxPrenume);
            this.Controls.Add(this.textBoxNume);
            this.Controls.Add(this.textBoxParola);
            this.Controls.Add(this.Telefon);
            this.Controls.Add(this.Oras);
            this.Controls.Add(this.Adresa);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.CNP);
            this.Controls.Add(this.Prenume);
            this.Controls.Add(this.Nume);
            this.Controls.Add(this.Parola);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.textBoxUsername);
            this.Controls.Add(this.label1);
            this.Name = "Inregistrare";
            this.Text = "InregistrareUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.Label Parola;
        private System.Windows.Forms.Label Nume;
        private System.Windows.Forms.Label Prenume;
        private System.Windows.Forms.Label CNP;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label Adresa;
        private System.Windows.Forms.Label Oras;
        private System.Windows.Forms.Label Telefon;
        private System.Windows.Forms.TextBox textBoxParola;
        private System.Windows.Forms.TextBox textBoxNume;
        private System.Windows.Forms.TextBox textBoxPrenume;
        private System.Windows.Forms.TextBox textBoxCNP;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxAdresa;
        private System.Windows.Forms.TextBox textBoxOras;
        private System.Windows.Forms.TextBox textBoxTelefon;
        private System.Windows.Forms.Button backLogIn;
        private System.Windows.Forms.Button buttonInregistrare;
    }
}